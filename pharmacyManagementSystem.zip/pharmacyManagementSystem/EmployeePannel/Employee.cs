﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace EmployeePannel
{
    public class Employee
    {
        static string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Arsla\Desktop\pharmacyManagementSystem\EmployeePannel\pharmacy.mdf;Integrated Security=True";

        static void Insert()
        {
            //insertion

            SqlConnection connection = new SqlConnection(connectionString);

            Console.WriteLine("Enter medicine Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Production Company name");
            string cName = Console.ReadLine();
            Console.WriteLine("Enter dose");
            int dose =Convert.ToInt32(Console.ReadLine());
           

            string query = "insert into medicine (name,Cname,dose) values('" + name + "','" + cName + "','" + dose +  "')"; 
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);

            int NumberOfInsertedRows = cmd.ExecuteNonQuery();

            connection.Close();

        }



        static void Delete()
        {
            //Deletion

            SqlConnection connection = new SqlConnection(connectionString);
            Console.WriteLine("Enter mId to delete");
            int ids = Convert.ToInt32(Console.ReadLine());


            string query = "delete from   medicine  where mid=@mid";//both of them should be of table name i.e id
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlParameter p1 = new SqlParameter("mid", ids);  //var in string should match the above but not a case sens

            cmd.Parameters.Add(p1);

            int NumberOfEffectedRows = cmd.ExecuteNonQuery();
            Console.WriteLine("No of Users Deleted =" + NumberOfEffectedRows);
            connection.Close();

        }


        static void Update()
        {
            //Updation

            SqlConnection connection = new SqlConnection(connectionString);

            Console.WriteLine("Enter mid to update its data");
            int mid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the medicine name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter company name");
            string Cname = Console.ReadLine();
            Console.WriteLine("Enter dose");
            int dose =Convert.ToInt32(Console.ReadLine());

            string query = "update medicine set  name=@name, Cname=@Cname,dose=@dose where mid= @mid";
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlParameter p1 = new SqlParameter("Cname", Cname);
            SqlParameter p3 = new SqlParameter("name", name);
            SqlParameter p2 = new SqlParameter("mID", mid);           
            SqlParameter p4 = new SqlParameter("dose", dose);
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            cmd.Parameters.Add(p3);
            cmd.Parameters.Add(p4);

            int NumberOfEffectedRows = cmd.ExecuteNonQuery();
            Console.WriteLine("No of Users Updates =" + NumberOfEffectedRows);
            connection.Close();

        }

        static void SingleObjectExample()
        {
            //reading

            SqlConnection connection = new SqlConnection(connectionString);




            string query = "select Count(*) cnt from medicine";


            SqlCommand cmd = new SqlCommand(query, connection);

            connection.Open();
            object value = cmd.ExecuteScalar();

            Console.WriteLine("Count of Users  = " + value);

        }

        void View() {

            SqlConnection connection = new SqlConnection(connectionString);
            // Create a connection string
            
            string SQL = "SELECT * FROM medicine";


            // Create a command object
            SqlCommand cmd = new SqlCommand(SQL, connection);
            connection.Open();

            // Call ExecuteReader to return a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            Console.WriteLine("\n\t\tMedicine ID,Medicine Name, " + "Production Comapny name,Dosage");
            Console.WriteLine("\n\t\t=============================");

            while (reader.Read())
            {
                Console.Write("\t\t" +reader["mid"].ToString() + "\t");
                Console.Write("\t\t" + reader["name"].ToString() + "\t");
                Console.Write("\t\t" + reader["Cname"].ToString() + "\t");
                Console.WriteLine("\t\t" + reader["dose"].ToString() + "\t");
            }

            //Release resources
            reader.Close();
            connection.Close();
            Console.WriteLine("\n\t\tPress any key to terminate");
            Console.ReadKey();

        }

        public  void Menu() {

            Console.WriteLine("\n\t\t What you want to do");
            Console.WriteLine("\n\t\t 1) Insert New medicine ");
            Console.WriteLine("\n\t\t 2) Update the medicine data");
            Console.WriteLine("\n\t\t 3) Delete the medicine");
            Console.WriteLine("\n\t\t 4) Display all record");

            int ch = Convert.ToInt32(Console.ReadLine());

            switch (ch) {

                case 1:
                    Console.Clear();
                    Console.WriteLine("\n\t\t-----INSERT NEW MEDICINE-----");
                    Insert();
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("\n\t\t-----UPDATE MEDICINE-----");
                    Update();
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("\n\t\t-----DELETE MEDICINE RECORD-----");
                    Delete();
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("\n\t\t-----Displaying all the Medicine Record-----");
                    View();
                    break;
            }

            
           
            

        }

    }
}
