﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using adminPannel;
using EmployeePannel;

namespace pharmacyManagementSystem
{
    class Program
    {
            static void Main(string[] args)
            {
                int choice;
         A:
                Console.WriteLine("\n\t\t How you want to be logged in");
                Console.WriteLine("\n\t\t Press 1 for Admin");
                Console.WriteLine("\n\t\t Press 2 for Employee");

                choice=  Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                switch (choice) {
    //ADMIN LOGIN
                    case 1:
                            Console.WriteLine("\n\t\t-----Admin login pannel-----");
                            admin a = new admin();
                    
                            //authentication if true then give it permission                
                            if (a.Authenticate() == true)
                            {
                                Console.WriteLine("\n\t\tpress any key to goto Admin pannel");
                                Console.ReadKey();                        
                                Console.Clear();

                                a.Menu();
                            }                  
                            break;
    //EMPLOYEE LOGIN
                    case 2:
                            Console.WriteLine("\n\t\t-----Employee Login pannel-----");

                            admin b = new admin();
                            //authentication                   
                            if (b.Authenticate() == true)
                            {
                                Console.WriteLine("\n\t\tpress any key to goto Employee pannel");
                                Console.ReadKey();                      
                                Console.Clear();
                                Employee emp = new Employee();
                                emp.Menu();
                            }
                            break;
     //Wrong CHOICE                   
                    default:
                            Console.WriteLine("\n\t\t wrong choice");
                            Console.Clear();
                            goto A;                   
                   }
                    
            }
    }
}
