﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace adminPannel
{
    public class admin {

        static string connectionString = @" Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Arsla\Desktop\pharmacyManagementSystem\adminPannel\Pharmacy.mdf;Integrated Security = True";

        static void Insert()
        {
            //insertion

            SqlConnection connection = new SqlConnection(connectionString);

            Console.WriteLine("Enter employee Name");
            string userName = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string password = Console.ReadLine();
            Console.WriteLine("Enter designation");
            string designation = Console.ReadLine();
            Console.WriteLine("Enter cell number");
            string number = Console.ReadLine();

            string query = "insert into Users (name,designation,number,pass) values('" + userName + "','"  + designation + "','" + number + "','"  + password + "')";
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);

            int NumberOfInsertedRows = cmd.ExecuteNonQuery();

            connection.Close();

        }


        static void Delete()
        {
            //Deletion

            SqlConnection connection = new SqlConnection(connectionString);
            Console.WriteLine("Enter Id to delete");
            int ids =Convert.ToInt32(Console.ReadLine());


            string query = "delete from   Users  where id=@id";//both of them should be of table name i.e id
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlParameter p1 = new SqlParameter("id", ids);  //var in string should match the above but not a case sens

            cmd.Parameters.Add(p1);

            int NumberOfEffectedRows = cmd.ExecuteNonQuery();
            Console.WriteLine("No of Users Deleted =" + NumberOfEffectedRows);
            connection.Close();

        }


        static void Update()
        {
            //Updation

            SqlConnection connection = new SqlConnection(connectionString);

            Console.WriteLine("Enter id to update its data");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the name");
            string userName = Console.ReadLine();
            Console.WriteLine("Enter designation");
            string designation = Console.ReadLine();
            Console.WriteLine("Enter cellNumber");
            string cell = Console.ReadLine();

            string query = "update  Users set  name= @name, designation=@designation,number=@number where id= @id";
            connection.Open();
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlParameter p1 = new SqlParameter("name", userName);
            SqlParameter p2 = new SqlParameter("ID", id);
            SqlParameter p3 = new SqlParameter("designation", designation);
            SqlParameter p4 = new SqlParameter("number", cell);
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            cmd.Parameters.Add(p3);
            cmd.Parameters.Add(p4);

            int NumberOfEffectedRows = cmd.ExecuteNonQuery();
            Console.WriteLine("No of Users Updates =" + NumberOfEffectedRows);
            connection.Close();

        }

        public bool Authenticate() {
            //reading

            SqlConnection connection = new SqlConnection(connectionString);

            Console.WriteLine("\n\t\tEnter your name && password");

            Console.WriteLine("Enter User Name");
            string userName = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string password = Console.ReadLine();


            //Preventing Injection
            //using Parameters
            string query = "select * from users where name = @name and pass = @Pass";
            SqlParameter p1 = new SqlParameter("name", userName);
            SqlParameter p2 = new SqlParameter("pass", password);

           // Console.WriteLine("query =" + query);
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                Console.WriteLine("Authenticated");
                return true;

            }
            else
            {
                Console.WriteLine("Invalid UserName/Password");
                return false;
            }

        }

        public void Menu() {

                Console.WriteLine("\n\t\t What you want to do");
                Console.WriteLine("\n\t\t 1) Insert New Employee ");
                Console.WriteLine("\n\t\t 2) Update the Employee Information");
                Console.WriteLine("\n\t\t 3) Delete Employee Data");

                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {

                    case 1:
                        Console.Clear();
                        Console.WriteLine("\n\t\t-----INSERT NEW EMPLOYEE-----");
                        Insert();
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("\n\t\t-----UPDATE EMPLOYEE DATA-----");
                        Update();
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("\n\t\t-----DELETE EMPLOYEE RECORD-----");
                        Delete();
                        break;
                }
           
        }



    }
}
